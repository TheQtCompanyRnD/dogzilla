_qt_internal_should_include_targets(
    TARGETS qdbuscpp2xml_native;qdbusxml2cpp_native
    NAMESPACE Qt6::
    OUT_VAR_SHOULD_SKIP __qt_DBusTools_skip_include_targets_file
)
