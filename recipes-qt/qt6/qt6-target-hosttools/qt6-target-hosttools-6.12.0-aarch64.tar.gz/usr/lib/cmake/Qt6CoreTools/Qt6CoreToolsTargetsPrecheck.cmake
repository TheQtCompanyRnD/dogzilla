_qt_internal_should_include_targets(
    TARGETS syncqt_native;moc_native;rcc_native;tracepointgen_native;tracegen_native;cmake_automoc_parser_native;qlalr_native;qtpaths_native;wasmdeployqt_native;qmake_native
    NAMESPACE Qt6::
    OUT_VAR_SHOULD_SKIP __qt_CoreTools_skip_include_targets_file
)
