_qt_internal_should_include_targets(
    TARGETS qvkgen_native
    NAMESPACE Qt6::
    OUT_VAR_SHOULD_SKIP __qt_GuiTools_skip_include_targets_file
)
